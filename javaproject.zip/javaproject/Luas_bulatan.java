public class Luas_bulatan {
    public static void main(String[] args) {
//pengisytiharan jenis data bagi pemalar dan pembolehubah
final double Pi=3.14159;
double jejari,luas;
//umpukan nilai bagi pembolehubah 
jejari=20;
//proses pengiraan 
luas=Pi*jejari*jejari;
//paparan output
System.out.println("luas bagi bulatan yang mempunyai jejari "+jejari+" adalah "+luas+" cm persegi");
    } 
}