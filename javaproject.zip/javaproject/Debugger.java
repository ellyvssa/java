public class Debugger {
    public static void main(String[] args) {
        String x = "Test";
        System.out.println(x);
    }
}
