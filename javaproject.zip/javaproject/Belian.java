public class Belian {
    public static void main(String[] args) {
//Pengisytiharan jenis data bagi pembolehubah 
    String barangan;
    int kuantiti;
    double harga,jumlah;

//umpukan nilai
    barangan="Biskut";
    kuantiti=7;
    harga=3.89;

//operasi
    jumlah= kuantiti*harga;

//Paparan output
    System.out.println("Info item:"+barangan);
    System.out.println("Unit dibeli:"+kuantiti);
    System.out.println("Harga Seunit: RM"+harga);
    System.out.println("Jumlah: RM"+jumlah);



    }
    
}
