public class Markah {
    public static void main(String[] args) {
        
//pengisytiharan data type
int jumlah, bm, sj;
double purata, peratus;

//umpukan nilai
bm = 79;
sj = 60;

//operasi
jumlah = bm+sj;
purata = jumlah/2;
peratus = jumlah/139*100;

//paparan output
System.out.println("jumlah markah:" + jumlah );
System.out.println("purata markah:" + purata );
System.out.println("peratus markah:" + peratus );


    }
    
}
