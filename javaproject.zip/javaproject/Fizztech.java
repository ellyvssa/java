public class Fizztech {
    public static void main(String[] args) {
        
        //pengisytiharan data type
        final double harga = 35.50;
        final double diskaun;

        //operasi pengiraan
        diskaun = harga- 3.55;

        //paparan output
        System.out.println("Harga Apacer USB Flash Drive 32GB: "+harga); 
        System.out.println("Harga selepas diskaun: "+diskaun);
    } 
}
