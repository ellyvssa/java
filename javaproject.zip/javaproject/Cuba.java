public class Cuba {
    public static void main(String[] args) {
        
        double r1 = Math.random();
        int r2 = (int) (Math.random()*20)-10;
        int r3 = (int) (Math.random()*5)+3;

        System.out.println("Nombor rawak 1: "+ r1);
        System.out.println("Nombor rawak 2: "+ r2);
        System.out.println("Nombor rawak 3: "+ r3);



    }
    
}
