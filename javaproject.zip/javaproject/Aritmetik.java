public class Aritmetik {
    public static void main(String[] args) {
        //pengisytiharan jenis data bagi pembolehubah 
        int x = 20;
        int y = 10;
        //operasi aritmetik
        x = x+y;
        //paparan output
        System.out.println("Hasil tambah ialah:"+x );
    }
}
